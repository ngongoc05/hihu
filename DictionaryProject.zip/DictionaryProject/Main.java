package DictionaryProject;

import DictionaryProject.controller.DictionaryController;

public class Main {
    public static void main(String[] args) {
         DictionaryController dictionaryController = new DictionaryController();
         dictionaryController.run();
    }
}
