package PersonManagement.Repository;

public interface IPersonRepository {
    public void findPersonInfo();

    public void coppyNewFile();
}
